# Pusat SMART Desa Negeri Selangor — Corporate Story Map

Fail ini ialah versi korporat/paparan awam untuk Story Map Pusat SMART Desa Negeri Selangor.

## Fail utama
- `index.html` — laman interaktif utama
- `data.json` — data lokasi yang digunakan oleh prototaip
- `assets/dashboard-reference.png` — rujukan visual reka bentuk

## Cara guna di GitHub
1. Buka repository GitHub anda.
2. Upload `index.html`, `data.json` dan folder `assets`.
3. Pastikan `index.html` berada di root repository.
4. Aktifkan GitHub Pages melalui Settings → Pages → Deploy from branch → `main` → `/ (root)`.

## Penting sebelum paparan awam
- Koordinat dalam prototaip ialah anggaran untuk visualisasi dan mesti diganti dengan koordinat GIS rasmi.
- Gambar “GAMBAR RASMI” ialah placeholder; gantikan dengan foto rasmi setiap Pusat SMART Desa.
- Status, peruntukan, KPI, tarikh siap dan maklumat pengurusan hendaklah disahkan oleh jabatan sebelum diterbitkan.
- Kandungan 18 lokasi adalah berasaskan dokumen projek perintis 2024; jangan anggap semua 18 lokasi sebagai status semasa tanpa pengesahan.
- Untuk versi akhir, setiap lokasi boleh diberi halaman/profil lengkap, galeri, dokumen dan KPI.

## Cadangan struktur profil awam
1. Profil Pusat
2. Lokasi & peta
3. Latar belakang kampung
4. Komponen kemudahan
5. Aktiviti komuniti
6. Status pelaksanaan
7. KPI / impak
8. Galeri
9. Dokumen berkaitan
10. Agensi / pengurusan
