# Story Map Pusat SMART Desa Negeri Selangor

Prototaip peta interaktif berasaskan dokumen cadangan Projek Perintis Showcase SMART Desa Negeri Selangor 2024 dan rujukan awam Negeri Selangor.

## Kandungan
- 18 lokasi saringan awal 2024
- 5 lokasi senarai pendek 2024
- 2 keutamaan segera 2024
- Profil terperinci untuk Kampung Sri Taman Baru dan Kampung Budiman berdasarkan dokumen sumber
- Search, filter daerah/status dan panel maklumat

## Penting
Koordinat dalam prototaip ini adalah anggaran untuk visualisasi dan perlu disahkan dengan data GIS rasmi sebelum diterbitkan sebagai sistem rasmi.
